from pathlib import Path
import hashlib
import zipfile
import argparse
import tempfile

# 원본 ZIP 파일 이름, SHA-256, 분할 파일 목록 (변경하지 마세요).
MANIFEST = {'author_processed_word.zip': {'sha256': '450c1732855223d4bdc2f8abdf1a6a26009d9c2b3a4939fa667d799b47623b35', 'size': 46901420, 'parts': ['author_processed_word.zip.part01', 'author_processed_word.zip.part02']}, 'author_processed_char.zip': {'sha256': '4d12c80dcfe808fddb982f76252c7d38d245f23fdfb042325903b59c6d0f1d7e', 'size': 238746366, 'parts': ['author_processed_char.zip.part01', 'author_processed_char.zip.part02', 'author_processed_char.zip.part03', 'author_processed_char.zip.part04', 'author_processed_char.zip.part05', 'author_processed_char.zip.part06', 'author_processed_char.zip.part07', 'author_processed_char.zip.part08', 'author_processed_char.zip.part09', 'author_processed_char.zip.part10']}}

def main():
    parser = argparse.ArgumentParser(description="Restore the two original dataset ZIPs and extract them together.")
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if (out / "processed").exists() or any((out / name).exists() for name in MANIFEST):
        raise SystemExit("Output already exists. Choose an empty folder with --output.")
    for info in MANIFEST.values():
        for part in info["parts"]:
            if not (source / part).is_file():
                raise SystemExit(f"Missing file: {part}")
    with tempfile.TemporaryDirectory(dir=out) as tmp:
        temp = Path(tmp)
        for name, info in MANIFEST.items():
            digest = hashlib.sha256()
            with (temp / name).open("wb") as target:
                for part in info["parts"]:
                    with (source / part).open("rb") as stream:
                        while True:
                            block = stream.read(1024 * 1024)
                            if not block:
                                break
                            target.write(block)
                            digest.update(block)
            if (temp / name).stat().st_size != info["size"] or digest.hexdigest() != info["sha256"]:
                raise SystemExit(f"Checksum mismatch: {name}")
            with zipfile.ZipFile(temp / name) as archive:
                bad = archive.testzip()
                if bad:
                    raise SystemExit(f"Corrupt ZIP entry: {bad}")
                archive.extractall(temp)
            print(f"Verified and extracted: {name}")
        for name in MANIFEST:
            (temp / name).replace(out / name)
        (temp / "processed").replace(out / "processed")
    print(f"Done: {out / 'processed'}")

if __name__ == "__main__":
    main()
