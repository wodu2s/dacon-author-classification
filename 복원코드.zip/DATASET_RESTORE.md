# 분할 데이터셋 복원 안내

## 공유 주의
대회 규정에 동의한 팀원에게만 데이터가 제공되도록 비공개 저장소를 사용하세요. 공개 저장소에 원본이나 가공 데이터를 업로드하지 마세요.

## 파일 구성
- `author_processed_word.zip.part01` ~ `part02`: 단어 단위 (불용어 유지/제거 및 공통 라벨)
- `author_processed_char.zip.part01` ~ `part10`: 글자 단위
- `restore_datasets.py`: 복원 및 SHA-256 검증 스크립트 (Python 표준 라이브러리만 사용)
- 기존 전처리 코드 5개는 변경하지 않았습니다.

## 복원 방법
1. GitHub의 Code > Download ZIP으로 저장소 전체를 내려받고 압축을 풉니다. (또는 분할 파일 12개와 복원 스크립트를 모두 같은 폴더에 다운로드합니다.)
2. 해당 폴더에서 터미널을 열고 실행합니다.

```bash
python restore_datasets.py
```

Windows에서 python 명령이 안 되면 `py restore_datasets.py`를 사용합니다. Colab에서는 모든 분할 파일과 스크립트를 같은 폴더에 넣고 `!python restore_datasets.py`를 실행합니다.

3. 원본 데이터 ZIP 두 개와 `processed/` 폴더가 생성됩니다. 파일 하나라도 없거나 손상되면 중단합니다. `processed/`가 이미 있다면 `python restore_datasets.py --output restored`처럼 새 폴더를 지정합니다.
4. 모델 학습은 기존 `README.md`의 설명에 따라 `processed/word_keep`, `processed/word_remove`, `processed/char`와 공통 라벨을 사용합니다. 출력 위치를 변경했다면 모델의 경로도 맞춰 주세요.

분할 파일은 일반 ZIP 파일이 아닙니다. 각각 압축 해제하지 말고 위 스크립트로 복원하세요. 복원 시 임시 공간을 포함해 여유 저장 공간 1GB 이상을 권장합니다.
