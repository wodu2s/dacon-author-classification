# 소설 작가 분류 — 텍스트 전처리

데이콘 원본: https://dacon.io/competitions/official/235670/data

## 실행 방법
1. 데이콘에서 원본 ZIP을 직접 다운로드합니다. 원본이나 생성 데이터는 공개 GitHub에 올리지 마세요. 팀원이 직접 받은 데이터로 아래 코드를 실행하면 같은 결과를 재현할 수 있습니다.
2. Colab에서 `preprocess.ipynb`를 열고 셀을 위에서부터 실행합니다. 또는 아래 명령으로 실행합니다.

```bash
pip install -r requirements.txt
python preprocess.py --input "원본파일.zip" --output processed
```

`--input`에는 train.csv, test_x.csv, sample_submission.csv가 들어 있는 폴더도 지정할 수 있습니다. 기본으로 세 가지 TF-IDF를 만듭니다. 하나만 실행하려면 `--variants word_keep`를 추가합니다.

## 전처리 기준
- 결측치/빈 글 검사, 연속 공백 정리 및 양끝 공백 제거. 문장부호와 숫자는 원문에서 유지합니다.
- 공백 정리 및 소문자 기준으로 동일한 텍스트에 서로 다른 작가 라벨이 있으면 해당 그룹 전체 제거. 동일 라벨 중복은 첫 행만 유지. 검증용 중복 유출을 방지하기 위한 선택이며 다른 방법도 가능.
- 학습/검증 80:20, `stratify=author`, `random_state=42`로 고정. 테스트 데이터는 행 제거/순서 변경 없이 유지.
- TF-IDF는 학습 데이터로만 fit, 검증 및 테스트는 transform만 사용.
- 공통: min_df=2, max_features=30000, lowercase=True, sublinear_tf=True, float32.
- word_keep: 단어 1~2그램, 불용어 유지 (기본 비교 기준).
- word_remove: 단어 1~2그램, scikit-learn 내장 영어 불용어 제거.
- char: 문자 3~5그램, 문장부호/공백 패턴 포함. 실제 성능은 아직 비교하지 않았음.

## 조원이 받는 데이터
`processed/` 아래에 공통 라벨 `y_train.npy`, `y_val.npy`, 테스트 ID `test_index.npy`, 정리된 텍스트 CSV 3개, 제출 양식, 검사 결과 `report.json`이 있습니다. 각 전처리 폴더의 `X_train.npz`, `X_val.npz`, `X_test.npz`는 희소행렬(0이 아닌 값 위주 저장), `vectorizer.joblib`은 변환기입니다. 행 순서는 공통 라벨과 일치합니다.

```python
from scipy.sparse import load_npz
import numpy as np
from pathlib import Path
p = Path('processed')
v = p / 'word_keep'  # 또는 word_remove, char
X_train = load_npz(v / 'X_train.npz')
X_val = load_npz(v / 'X_val.npz')
X_test = load_npz(v / 'X_test.npz')
y_train = np.load(p / 'y_train.npy')
y_val = np.load(p / 'y_val.npy')
print(X_train.shape, X_val.shape, X_test.shape)
```

나이브 베이즈 및 앙상블 담당자는 동일한 검증 데이터와 `log_loss(y_val, model.predict_proba(X_val), labels=[0,1,2,3,4])`를 사용하세요. 클래스 확률 열 순서는 `model.classes_`가 0~4인지 확인하세요. 배깅/부스팅은 모델에 따라 희소행렬 지원 여부를 확인하고, 전체 행렬을 무조건 dense로 바꾸지 마세요.

최종 모델 선정 후에는 `train_clean.csv`, `val_clean.csv`를 합쳐 **새로운 TF-IDF 변환기와 최종 모델을 전체 정리된 학습 데이터에 재학습**하고 test_clean.csv를 변환해 예측할 수 있습니다. 검증용 변환기를 전체 학습에 그대로 재사용하지 않아도 됩니다. 제출은 원래 test index 순서 및 0~4 확률 열을 유지합니다. 이 저장소는 전처리까지만 포함하고 모델 성능/데이콘 제출은 포함하지 않습니다.

## GitHub 공유
데이터 재배포 조건 확인 전에는 비공개 팀 저장소에 코드, README, requirements, .gitignore만 올리고 각 팀원이 데이콘에서 직접 다운로드한 ZIP으로 실행하는 것이 안전합니다. 생성 파일을 공유할 경우 권한과 용량을 확인하세요. 저장된 joblib은 신뢰하는 출처의 파일만 읽으세요.
