"""DACON novel author classification: preprocessing only."""
import argparse
import json
from pathlib import Path
import zipfile
import joblib
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split

SEED = 42
CONFIGS = {
    'word_keep': dict(analyzer='word', ngram_range=(1, 2), stop_words=None),
    'word_remove': dict(analyzer='word', ngram_range=(1, 2), stop_words='english'),
    'char': dict(analyzer='char', ngram_range=(3, 5)),
}


def load_data(source):
    source = Path(source)
    names = ['train.csv', 'test_x.csv', 'sample_submission.csv']
    if source.is_file():
        with zipfile.ZipFile(source) as z:
            return tuple(pd.read_csv(z.open(name)) for name in names)
    return tuple(pd.read_csv(source / name) for name in names)


def clean_text(series):
    # 문체 정보 보존: 문장부호, 숫자, 불용어를 여기서 삭제하지 않습니다.
    return series.fillna('').str.replace(r'\s+', ' ', regex=True).str.strip()


def prepare(train, test, submission):
    train = train.copy()
    test = test.copy()
    assert train['index'].is_unique and test['index'].is_unique
    assert set(train['author'].dropna()) == set(range(5))
    assert submission['index'].equals(test['index'])
    original = len(train)
    missing = train.isna().sum().to_dict()
    raw_duplicates = int(train['text'].duplicated().sum())
    train['text'] = clean_text(train['text'])
    test['text'] = clean_text(test['text'])
    blank = int(train['text'].eq('').sum())
    train = train.loc[train['text'].ne('') & train['author'].notna()].copy()
    # TF-IDF 소문자 변환과 동일한 기준으로 중복을 판정합니다.
    train['_key'] = train['text'].str.lower()
    normalized_duplicates = int(train['_key'].duplicated().sum())
    counts = train.groupby('_key')['author'].nunique()
    conflicts = counts[counts > 1].index
    conflict_mask = train['_key'].isin(conflicts)
    conflict_rows = int(conflict_mask.sum())
    train = train.loc[~conflict_mask].copy()
    same_label_duplicates = int(train['_key'].duplicated().sum())
    train = train.drop_duplicates('_key', keep='first').drop(columns='_key')
    train['author'] = train['author'].astype(int)
    # 작가별 비율을 유지하는 80:20 학습/검증 분리
    tr, va = train_test_split(train, test_size=0.2, random_state=SEED, stratify=train['author'])
    tr = tr.reset_index(drop=True)
    va = va.reset_index(drop=True)
    assert not set(tr['text'].str.lower()) & set(va['text'].str.lower())
    report = dict(original_train=original, missing=missing, blank_train=blank,
                  raw_duplicate_texts=raw_duplicates, normalized_duplicate_texts=normalized_duplicates,
                  conflict_groups=len(conflicts), conflict_rows_removed=conflict_rows,
                  same_label_duplicate_rows_removed=same_label_duplicates,
                  cleaned_train=len(train), train_rows=len(tr), val_rows=len(va), test_rows=len(test),
                  train_author_counts=tr.author.value_counts().sort_index().to_dict(),
                  val_author_counts=va.author.value_counts().sort_index().to_dict(), random_state=SEED)
    return tr, va, test, report


def make_vectorizer(name):
    return TfidfVectorizer(**CONFIGS[name], lowercase=True, min_df=2,
                           max_features=30000, sublinear_tf=True, dtype=np.float32)


def save_features(name, tr, va, test, out):
    folder = out / name
    folder.mkdir(parents=True, exist_ok=True)
    vectorizer = make_vectorizer(name)
    # fit_transform은 학습용에만! 검증/테스트는 transform만 합니다.
    matrices = {'X_train': vectorizer.fit_transform(tr['text']),
                'X_val': vectorizer.transform(va['text']),
                'X_test': vectorizer.transform(test['text'])}
    stats = {}
    for key, matrix in matrices.items():
        matrix = matrix.tocsr()
        sparse.save_npz(folder / (key + '.npz'), matrix)
        stats[key] = dict(shape=list(matrix.shape), nnz=int(matrix.nnz),
                          zero_rows=int((matrix.getnnz(axis=1) == 0).sum()))
    joblib.dump(vectorizer, folder / 'vectorizer.joblib', compress=3)
    return stats


def run(source, output='processed', variants=None):
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    train, test, submission = load_data(source)
    tr, va, test, report = prepare(train, test, submission)
    tr.to_csv(out / 'train_clean.csv', index=False)
    va.to_csv(out / 'val_clean.csv', index=False)
    test.to_csv(out / 'test_clean.csv', index=False)
    submission.to_csv(out / 'sample_submission.csv', index=False)
    np.save(out / 'y_train.npy', tr.author.to_numpy())
    np.save(out / 'y_val.npy', va.author.to_numpy())
    np.save(out / 'test_index.npy', test['index'].to_numpy())
    report['features'] = {}
    for name in (variants or CONFIGS):
        print('TF-IDF:', name, flush=True)
        report['features'][name] = save_features(name, tr, va, test, out)
    (out / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='원본 zip 또는 CSV 3개가 있는 폴더')
    parser.add_argument('--output', default='processed')
    parser.add_argument('--variants', nargs='+', choices=list(CONFIGS))
    args = parser.parse_args()
    run(args.input, args.output, args.variants)
